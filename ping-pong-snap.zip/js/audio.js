/* Ping-Pong-Snap procedural audio — WebAudio, no assets. Global: window.GameAudio */
(function () {
  var ctx = null, master = null, muted = false, humNodes = null;
  function ensure() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return true; }
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.5; master.connect(ctx.destination);
      return true;
    } catch (e) { return false; }
  }
  function env(g, t0, a, peak, d) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(peak, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d);
  }
  function tone(freq, dur, type, vol, slideTo) {
    if (muted || !ensure()) return;
    var t0 = ctx.currentTime;
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    env(g, t0, 0.005, vol || 0.4, dur);
    o.connect(g); g.connect(master); o.start(t0); o.stop(t0 + dur + 0.05);
  }
  function noise(dur, vol, filterFreq, type) {
    if (muted || !ensure()) return;
    var t0 = ctx.currentTime;
    var len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    var src = ctx.createBufferSource(); src.buffer = buf;
    var f = ctx.createBiquadFilter(); f.type = type || 'highpass'; f.frequency.value = filterFreq || 2000;
    var g = ctx.createGain(); env(g, t0, 0.003, vol || 0.4, dur);
    src.connect(f); f.connect(g); g.connect(master); src.start(t0); src.stop(t0 + dur + 0.05);
  }
  window.GameAudio = {
    unlock: function () { ensure(); },
    toggleMute: function () { muted = !muted; return muted; },
    isMuted: function () { return muted; },
    ping: function () { tone(1560 + Math.random() * 320, 0.28, 'sine', 0.5); tone(3120, 0.12, 'sine', 0.15); },
    jump: function () { tone(300, 0.14, 'square', 0.12, 620); },
    boing: function (s) { var k = Math.min(1.6, 0.7 + (s || 0)); tone(180, 0.28, 'sine', 0.5, 180 + 420 * k); },
    twigSnap: function () { noise(0.09, 0.5, 2800, 'bandpass'); noise(0.05, 0.3, 5000, 'highpass'); },
    snapStep: function () { noise(0.07, 0.35, 2200 + Math.random() * 1600, 'bandpass'); },
    bonk: function () { tone(140, 0.12, 'square', 0.3, 90); noise(0.06, 0.25, 800, 'lowpass'); },
    squish: function () { noise(0.18, 0.7, 900, 'lowpass'); tone(200, 0.25, 'sawtooth', 0.4, 40); },
    warn: function () { tone(660, 0.15, 'square', 0.3); setTimeout(function () { tone(660, 0.15, 'square', 0.3); }, 160); },
    headSnap: function () { noise(0.12, 0.7, 1500, 'bandpass'); tone(160, 0.3, 'sawtooth', 0.4, 45); noise(0.3, 0.4, 300, 'lowpass'); },
    scare: function () {
      // jumpscare sting: loud shriek + slam. Deliberately harsh.
      tone(1700, 0.5, 'sawtooth', 0.55, 280);
      tone(95, 0.6, 'sawtooth', 0.6, 35);
      noise(0.45, 0.65, 3500, 'highpass');
      noise(0.5, 0.6, 250, 'lowpass');
    },
    die: function () { tone(220, 0.35, 'sawtooth', 0.35, 55); },
    win: function () { var n = [523, 659, 784, 1046]; for (var i = 0; i < n.length; i++) (function (f, i) { setTimeout(function () { tone(f, 0.22, 'triangle', 0.4); }, i * 110); })(n[i], i); },
    goal: function () { tone(880, 0.2, 'triangle', 0.35, 1320); }
  };
})();
