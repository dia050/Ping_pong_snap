/* Particles + screen shake + toasts. Global: Effects */
(function () {
  var parts = [], shake = 0;
  function burst(x, y, color, n) {
    for (var i = 0; i < (n || 12); i++) {
      parts.push({ x: x + (Math.random() - 0.5) * 20, y: y - 20 + (Math.random() - 0.5) * 20, vx: (Math.random() - 0.5) * 420, vy: -Math.random() * 420, life: 0.5 + Math.random() * 0.5, t: 0, c: color });
    }
    shake = Math.max(shake, 8);
  }
  function jumpPuff(x, y) {
    for (var i = 0; i < 6; i++) parts.push({ x: x + (Math.random() - 0.5) * 18, y: y, vx: (Math.random() - 0.5) * 120, vy: -Math.random() * 120, life: 0.35, t: 0, c: '#bff6ff' });
  }
  function update(dt) {
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i]; p.t += dt;
      if (p.t >= p.life) { parts.splice(i, 1); continue; }
      p.vy += 900 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
    }
    if (shake > 0) shake = Math.max(0, shake - dt * 30);
  }
  function draw(ctx, camX) {
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i], a = 1 - p.t / p.life;
      ctx.globalAlpha = a; ctx.fillStyle = p.c;
      ctx.fillRect(p.x - camX - 3, p.y - 3, 6, 6);
    }
    ctx.globalAlpha = 1;
  }
  function applyShake(ctx) {
    if (shake > 0) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
  }
  function trauma(n) { shake = Math.max(shake, n || 14); }
  var toastEl = null, toastTimer = 0;
  function toast(msg, ms) {
    if (!toastEl) toastEl = document.getElementById('toast');
    if (!toastEl) return;
    toastEl.innerHTML = msg; toastEl.style.opacity = 1;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.style.opacity = 0; }, ms || 1400);
  }
  window.Effects = { burst: burst, jumpPuff: jumpPuff, update: update, draw: draw, applyShake: applyShake, trauma: trauma, toast: toast };
})();
