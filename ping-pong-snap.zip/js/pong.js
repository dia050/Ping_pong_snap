/* PONG: normal obstacle road + RANDOM bouncy curse. Floor suddenly turns trampoline,
   you launch into low ceilings/walls and get SQUISHED. Global: PongSys */
(function () {
  function PongSys(level) {
    this.level = level;
    this.squash = {};
    this.reset();
  }
  PongSys.prototype.scheduleNext = function () {
    var c = this.level.curse || { periodMin: 7, periodMax: 11 };
    this.nextIn = c.periodMin + Math.random() * (c.periodMax - c.periodMin);
  };
  PongSys.prototype.reset = function () {
    this.squash = {};
    this.bouncy = false;
    this.bouncyT = 0;
    this.scheduleNext();
  };
  PongSys.prototype.isBouncy = function () { return this.bouncy; };
  PongSys.prototype.bounce = function (platIdx, impactVY) {
    this.squash[platIdx] = 1;
    var s = Math.min(1.8, 0.6 + Math.abs(impactVY) / 800);
    if (window.GameAudio) window.GameAudio.boing(s);
    var mult = (this.level.bounce && this.level.bounce.mult) || 1.6;
    return -(720 * mult + Math.abs(impactVY) * 0.28);
  };
  PongSys.prototype.update = function (dt, player) {
    for (var k in this.squash) {
      this.squash[k] -= dt * 4;
      if (this.squash[k] <= 0) delete this.squash[k];
    }
    if (player && player.dead) return;
    if (this.bouncy) {
      this.bouncyT -= dt;
      if (this.bouncyT <= 0) { this.bouncy = false; this.scheduleNext(); }
    } else {
      this.nextIn -= dt;
      if (this.nextIn <= 0) {
        this.bouncy = true;
        this.bouncyT = (this.level.curse && this.level.curse.duration) || 2.5;
        if (window.GameAudio) { window.GameAudio.boing(1.6); window.GameAudio.ping(); }
        if (window.Effects) window.Effects.toast('⚠ FLOOR BOUNCY! ⚠<br><span style="font-size:14px">don\'t jump — you\'ll get SQUISHED</span>', 1400);
      }
    }
  };
  PongSys.prototype.squashAt = function (i) { return this.squash[i] || 0; };

  function overlap(ax1, ax2, ay1, ay2, bx1, bx2, by1, by2) {
    return ax1 < bx2 && ax2 > bx1 && ay1 < by2 && ay2 > by1;
  }

  PongSys.prototype.checkHazards = function (player, plats) {
    var lvl = this.level;
    var list = lvl.staticSpikes || [];
    for (var i = 0; i < list.length; i++) {
      var sx = list[i].dx, sw = list[i].w, gy = null;
      for (var j = 0; j < plats.length; j++) { var p = plats[j]; if (sx >= p.x && sx <= p.x + p.w) { gy = p.y; break; } }
      if (gy === null) continue;
      if (!player.dead && overlap(player.x - 10, player.x + 10, player.y - player.h, player.y, sx, sx + sw, gy - 34, gy)) {
        player.kill(false);
        if (window.Effects) window.Effects.toast('PONG SPIKED!', 900);
        return 'spike';
      }
    }
    // low bars: bonk down
    var bars = lvl.lowBars || [];
    for (var b = 0; b < bars.length; b++) {
      var bx = bars[b].dx, bw = bars[b].w;
      var top = 440 - 130, bot = top + bars[b].h;
      if (!player.dead && overlap(player.x - 10, player.x + 10, player.y - player.h, player.y, bx, bx + bw, top, bot)) {
        if (player.vy < 0) {
          if (this.bouncy && player.vy < -550) {
            player.kill(false);
            if (window.Effects) window.Effects.toast('SQUISHED!', 1100);
            if (window.GameAudio) window.GameAudio.headSnap();
            return 'squish';
          }
          player.vy = 140;
          if (window.Effects) window.Effects.burst(player.x, player.y - player.h, '#ffb13d', 5);
        }
      }
    }
    // ceilings: the squish walls. High-speed head hit while bouncy = death.
    var ceils = lvl.ceilings || [];
    for (var c = 0; c < ceils.length; c++) {
      var cl = ceils[c];
      var head = player.y - player.h;
      if (!player.dead && player.x + 10 > cl.x && player.x - 10 < cl.x + cl.w && head < cl.bottom + 2 && head > cl.top - 70) {
        if (player.vy < 0) {
          if (this.bouncy && player.vy < -480) {
            player.kill(false);
            if (window.Effects) { window.Effects.toast('SQUISHED ON THE CEILING!', 1200); window.Effects.burst(player.x, head, '#ff5d5d', 18); }
            if (window.GameAudio) window.GameAudio.headSnap();
            return 'squish';
          }
          player.vy = 140; // bonk
          if (window.Effects) window.Effects.burst(player.x, head, '#c9d4cc', 5);
          if (window.GameAudio) window.GameAudio.bonk();
        }
        // spiked ceiling lips: graze = death even without speed
        if (cl.spiked && !player.dead && head < cl.bottom && head > cl.bottom - 26 &&
            player.x + 10 > cl.x + 20 && player.x - 10 < cl.x + cl.w - 20) {
          player.kill(false);
          if (window.Effects) window.Effects.toast('CEILING SPIKES!', 1000);
          return 'cspike';
        }
      }
    }
    return null;
  };

  PongSys.prototype.drawStatic = function (ctx, camX, plats, t) {
    var lvl = this.level;
    var list = lvl.staticSpikes || [];
    for (var i = 0; i < list.length; i++) {
      var sx = list[i].dx, gy = null;
      for (var j = 0; j < plats.length; j++) { var p = plats[j]; if (sx >= p.x && sx <= p.x + p.w) { gy = p.y; break; } }
      if (gy !== null) window.World.drawSpike(ctx, sx - camX, gy, list[i].w, 34, '#ffb13d');
    }
    var bars = lvl.lowBars || [];
    ctx.save();
    for (var b = 0; b < bars.length; b++) {
      var bx = bars[b].dx - camX;
      if (bx + bars[b].w < -60 || bx > 1100) continue;
      ctx.fillStyle = '#3f4a44'; ctx.fillRect(bx, 440 - 130, bars[b].w, bars[b].h);
      ctx.fillStyle = '#ff9a2a';
      for (var hx = 0; hx < bars[b].w; hx += 30) ctx.fillRect(bx + hx, 440 - 130 + bars[b].h - 12, 18, 12);
      ctx.strokeStyle = '#000'; ctx.lineWidth = 2; ctx.strokeRect(bx, 440 - 130, bars[b].w, bars[b].h);
    }
    // ceilings / squish slabs
    for (var c = 0; c < (lvl.ceilings || []).length; c++) {
      var cl = lvl.ceilings[c], cx = cl.x - camX;
      if (cx + cl.w < -60 || cx > 1100) continue;
      var pulse = this.bouncy ? (0.5 + 0.5 * Math.sin((t || 0) * 12)) : 0;
      ctx.fillStyle = this.bouncy ? '#5a2020' : '#3a4440';
      ctx.fillRect(cx, cl.top, cl.w, cl.bottom - cl.top);
      ctx.fillStyle = this.bouncy ? 'rgba(255,60,60,' + (0.4 + pulse * 0.4) + ')' : '#ff9a2a';
      ctx.fillRect(cx, cl.bottom - 8, cl.w, 8);
      ctx.fillStyle = '#1a2b1d';
      for (var sx2 = 0; sx2 < cl.w; sx2 += 34) {
        ctx.beginPath(); ctx.moveTo(cx + sx2, cl.bottom); ctx.lineTo(cx + sx2 + 15, cl.bottom - 8); ctx.lineTo(cx + sx2 + 26, cl.bottom); ctx.fill();
      }
      if (cl.spiked) {
        ctx.fillStyle = '#e8ecf1';
        var teeth = Math.floor(cl.w / 22);
        for (var ti = 0; ti < teeth; ti++) {
          var tx = cx + 10 + ti * 22;
          ctx.beginPath(); ctx.moveTo(tx, cl.bottom); ctx.lineTo(tx + 8, cl.bottom + 20); ctx.lineTo(tx + 16, cl.bottom); ctx.fill();
        }
      }
      ctx.strokeStyle = '#000'; ctx.lineWidth = 2; ctx.strokeRect(cx, cl.top, cl.w, cl.bottom - cl.top);
      // support struts
      ctx.fillStyle = '#243d28'; ctx.fillRect(cx + 6, cl.top - 40, 12, 40); ctx.fillRect(cx + cl.w - 18, cl.top - 40, 12, 40);
    }
    ctx.restore();
  };
  window.PongSys = PongSys;
})();
