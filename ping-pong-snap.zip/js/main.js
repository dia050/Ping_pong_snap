/* Main loop + physics + 15-level flow. */
(function () {
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');
  var W = canvas.width, H = canvas.height;
  var overlay = document.getElementById('overlay');
  var hudWorld = document.getElementById('hud-world');
  var hudHint = document.getElementById('hud-hint');
  var hudDeaths = document.getElementById('hud-deaths');

  var input = { left: false, right: false };
  var keys = {};
  var state = 'menu';
  var worldKey = 'ping', levelIdx = 0, level = null, plats = [];
  var player = new window.Player(60, 300);
  var pingSys = null, pongSys = null, snapSys = null;
  var camX = 0, tGlobal = 0, deaths = 0, deathCounted = false, won = false, winT = 0;
  var phys = { gravity: 2100, moveSpeed: 275, jumpForce: 745 };

  function getLevel(w, i) { return window.PPS_LEVELS[w][i || 0]; }
  function levelCount(w) { return window.PPS_LEVELS[w].length; }
  var ORDER = ['ping', 'pong', 'snap'];

  // ---- progression gate: next world needs 4/5 of previous (finish all, 1 skip allowed);
  // ---- within a world, level N needs N-2 cleared before it (max 1 skip per stage).
  function clearedCount(w) {
    var n = 0;
    try { for (var i = 0; i < levelCount(w); i++) if (localStorage.getItem('pps_win_' + w + '_' + i)) n++; } catch (e) {}
    return n;
  }
  function isUnlocked(w, idx) {
    var wi = ORDER.indexOf(w);
    if (wi < 0) return false;
    for (var k = 0; k < wi; k++) if (clearedCount(ORDER[k]) < 4) return false;
    var before = 0;
    try { for (var j = 0; j < idx; j++) if (localStorage.getItem('pps_win_' + w + '_' + j)) before++; } catch (e) {}
    return before >= idx - 1;
  }
  function lockReason(w, idx) {
    var wi = ORDER.indexOf(w);
    for (var k = 0; k < wi; k++) {
      if (clearedCount(ORDER[k]) < 4) {
        var need = ORDER[k].toUpperCase();
        return 'need 4/5 ' + need + ' first (1 skip allowed) — have ' + clearedCount(ORDER[k]) + '/5';
      }
    }
    return 'clear an earlier level first (only 1 skip per stage)';
  }
  window.PPS_isUnlocked = isUnlocked;

  // ---- jumpscare: fullscreen flash on every death (worse in SNAP).
  var scareEl = null, scareTimer = 0;
  function jumpscare(snap) {
    if (!scareEl) scareEl = document.getElementById('jumpscare');
    if (scareEl) {
      var face = scareEl.querySelector('.scare-face');
      var word = scareEl.querySelector('.scare-word');
      var faces = snap ? ['💀', '🩸', '👹'] : ['👹', '👺', '💀'];
      if (face) face.textContent = faces[Math.floor(Math.random() * faces.length)];
      if (word) word.textContent = snap ? 'HEAD SNAP' : 'YOU DIED';
      scareEl.classList.remove('show');
      void scareEl.offsetWidth; // restart CSS animation
      scareEl.classList.add('show');
      clearTimeout(scareTimer);
      scareTimer = setTimeout(function () { scareEl.classList.remove('show'); }, snap ? 950 : 750);
    }
    if (window.GameAudio) window.GameAudio.scare();
  }

  function loadWorld(w, idx) {
    idx = idx || 0;
    if (!isUnlocked(w, idx)) {
      if (window.Effects) window.Effects.toast('🔒 ' + w.toUpperCase() + ' ' + (idx + 1) + ' LOCKED<br><span style="font-size:14px">' + lockReason(w, idx) + '</span>', 2200);
      toMenu();
      return;
    }
    level = getLevel(w, idx);
    worldKey = w; levelIdx = idx;
    plats = level.plats.slice();
    if (w === 'snap' && level.upperBranch) plats = plats.concat(level.upperBranch);
    player.reset(level.start.x, level.start.y);
    pingSys = (w === 'ping') ? new window.PingSys(level) : null;
    pongSys = (w === 'pong') ? new window.PongSys(level) : null;
    snapSys = (w === 'snap') ? new window.SnapSys(level) : null;
    camX = -60; deaths = 0; deathCounted = false; won = false; winT = 0;
    hudWorld.textContent = level.name;
    hudHint.textContent = level.hint;
    hudDeaths.textContent = 'Rebirths: 0';
    overlay.classList.remove('show');
    state = 'play';
    if (window.GameAudio) window.GameAudio.unlock();
    if (window.Effects) window.Effects.toast(level.name + '<br><span style="font-size:14px">' + shortTip(w) + '</span>', 1800);
  }
  window.PPS_load = loadWorld;
  function shortTip(w) {
    if (w === 'ping') return 'A/D move · Space jump · spikes pop with PINGG';
    if (w === 'pong') return 'obstacles ahead · floor randomly BOUNCY · mind the ceiling!';
    return 'floor looks normal but every step cracks SNAP (decoy) · hidden curse kills';
  }
  function toMenu() { state = 'menu'; overlay.classList.add('show'); refreshMenuProgress(); }
  function rebirth(manual) {
    deaths++; hudDeaths.textContent = 'Rebirths: ' + deaths;
    player.reset(level.start.x, level.start.y);
    if (pingSys) pingSys.reset();
    if (pongSys) pongSys.reset();
    if (snapSys) snapSys.reset();
    deathCounted = false; won = false;
    if (manual && window.Effects) window.Effects.toast('REBIRTH #' + deaths + (worldKey === 'snap' ? '<br><span style="font-size:14px">curse reshuffled · cause hidden</span>' : ''), 1300);
  }
  function nextLevel() {
    // advance within world if open, else hop to next world's level 1 if unlocked, else menu
    if (levelIdx + 1 < levelCount(worldKey) && isUnlocked(worldKey, levelIdx + 1)) { loadWorld(worldKey, levelIdx + 1); return; }
    var wi = ORDER.indexOf(worldKey);
    if (wi >= 0 && wi + 1 < ORDER.length && isUnlocked(ORDER[wi + 1], 0)) { loadWorld(ORDER[wi + 1], 0); return; }
    toMenu();
  }
  function refreshMenuProgress() {
    try {
      var btns = document.querySelectorAll('[data-play]');
      for (var i = 0; i < btns.length; i++) {
        var w = btns[i].getAttribute('data-play'), li = parseInt(btns[i].getAttribute('data-level') || '0', 10);
        var done = localStorage.getItem('pps_win_' + w + '_' + li);
        var open = isUnlocked(w, li);
        btns[i].classList.toggle('done', !!done);
        btns[i].classList.toggle('locked', !open);
        btns[i].disabled = !open;
        btns[i].title = open ? (done ? 'cleared — replay' : 'play') : lockReason(w, li);
        var base = String(li + 1);
        if (!open) base = '🔒' + base;
        else if (done) base = '✔' + base;
        if (btns[i].textContent !== base) btns[i].textContent = base;
      }
      var note = document.getElementById('locknote');
      if (note) {
        var p = clearedCount('ping'), q = clearedCount('pong');
        note.textContent = 'PING ' + p + '/5 · PONG ' + q + '/5 — PONG needs 4/5 PING, SNAP needs 4/5 PONG. Max 1 skip per stage.';
      }
    } catch (e) {}
  }

  window.addEventListener('keydown', function (e) {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'Space'].indexOf(e.code) >= 0) e.preventDefault();
    if (window.GameAudio) window.GameAudio.unlock();
    if (e.code === 'Escape') { if (state === 'play') toMenu(); return; }
    if (e.code === 'KeyM') { toggleMute(); return; }
    if (e.code === 'KeyR' && state === 'play') { rebirth(true); return; }
    if (e.code === 'KeyN' && won) { nextLevel(); return; }
    if (e.repeat) return;
    keys[e.code] = true;
    syncInput();
    if ((e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') && state === 'play' && !player.dead && !won) player.jumpBuf = 0.13;
    if ((e.code === 'ArrowLeft' || e.code === 'KeyA') && state === 'play' && !player.dead) player.leftPresses++;
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; syncInput(); });
  var touchHeld = {}; // 'left' | 'right' -> count of active pointers
  function syncInput() {
    input.left = !!(keys.ArrowLeft || keys.KeyA) || (touchHeld.left > 0);
    input.right = !!(keys.ArrowRight || keys.KeyD) || (touchHeld.right > 0);
  }
  // Touch: visible buttons (multi-touch) + canvas tap zones as fallback.
  // Every press is tracked by pointerId and cleared on up/cancel/leave,
  // so a cancelled touch can never stick movement on ("auto move" bug).
  (function () {
    var ptrRole = {}; // pointerId -> 'left' | 'right'
    function markTouch() { if (document.body.classList) document.body.classList.add('touch'); }
    if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) markTouch();
    window.addEventListener('touchstart', markTouch, { passive: true });
    function press(role, id) {
      if (window.GameAudio) window.GameAudio.unlock();
      if (state !== 'play' || player.dead) return;
      if (role === 'jump') { player.jumpBuf = 0.13; return; }
      if (ptrRole[id]) release(id);
      ptrRole[id] = role;
      touchHeld[role] = (touchHeld[role] || 0) + 1;
      if (role === 'left') player.leftPresses++;
      var btn = document.getElementById(role === 'left' ? 't-left' : 't-right');
      if (btn && btn.classList) btn.classList.add('held');
      syncInput();
    }
    function release(id) {
      var role = ptrRole[id];
      if (!role) return;
      delete ptrRole[id];
      touchHeld[role] = Math.max(0, (touchHeld[role] || 1) - 1);
      var btn = document.getElementById(role === 'left' ? 't-left' : 't-right');
      if (btn && btn.classList) btn.classList.remove('held');
      syncInput();
    }
    function bindHold(el, role) {
      if (!el) return;
      el.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        try { el.setPointerCapture(e.pointerId); } catch (err) {}
        press(role, e.pointerId);
      });
      el.addEventListener('pointerup', function (e) { release(e.pointerId); });
      el.addEventListener('pointercancel', function (e) { release(e.pointerId); });
      el.addEventListener('lostpointercapture', function (e) { release(e.pointerId); });
      el.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    }
    bindHold(document.getElementById('t-left'), 'left');
    bindHold(document.getElementById('t-right'), 'right');
    var tj = document.getElementById('t-jump');
    if (tj) {
      tj.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        if (window.GameAudio) window.GameAudio.unlock();
        if (state === 'play' && !player.dead && !won) player.jumpBuf = 0.15;
        if (tj.classList) { tj.classList.add('held'); setTimeout(function () { tj.classList.remove('held'); }, 150); }
      });
      tj.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    }
    // Fallback: taps directly on canvas (left/right halves move, top area jumps)
    var canvasIds = {};
    canvas.addEventListener('pointerdown', function (e) {
      if (window.GameAudio) window.GameAudio.unlock();
      markTouch();
      if (state !== 'play') return;
      var r = canvas.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width;
      var y = (e.clientY - r.top) / r.height;
      if (y < 0.45) { if (!player.dead && !won) player.jumpBuf = 0.13; return; }
      press(x < 0.4 ? 'left' : 'right', 'c' + e.pointerId);
      canvasIds[e.pointerId] = true;
    });
    function canvasRelease(e) { if (canvasIds[e.pointerId]) { delete canvasIds[e.pointerId]; release('c' + e.pointerId); } }
    canvas.addEventListener('pointerup', canvasRelease);
    canvas.addEventListener('pointercancel', canvasRelease);
    // Safety net: any top-level release clears orphaned holds (kills stuck runs)
    window.addEventListener('blur', function () { ptrRole = {}; touchHeld = {}; syncInput(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { ptrRole = {}; touchHeld = {}; syncInput(); }
    });
  })();

  function toggleMute() {
    if (!window.GameAudio) return;
    var m = window.GameAudio.toggleMute();
    document.getElementById('btn-mute').textContent = m ? '🔇' : '🔊';
  }
  document.getElementById('btn-mute').addEventListener('click', toggleMute);
  document.getElementById('btn-menu').addEventListener('click', toMenu);
  var btns = document.querySelectorAll('[data-play]');
  for (var i = 0; i < btns.length; i++) (function (b) {
    b.addEventListener('click', function () {
      var w = b.getAttribute('data-play'), li = parseInt(b.getAttribute('data-level') || '0', 10);
      if (!isUnlocked(w, li)) {
        if (window.GameAudio) window.GameAudio.bonk();
        if (window.Effects) window.Effects.toast('🔒 LOCKED<br><span style="font-size:14px">' + lockReason(w, li) + '</span>', 2200);
        refreshMenuProgress();
        return;
      }
      loadWorld(w, li);
    });
  })(btns[i]);

  function collide(dt) {
    var prevY = player.y - player.vy * dt;
    player.onGround = false;
    var landedIdx = -1, landedPlat = null;
    for (var i = 0; i < plats.length; i++) {
      var p = plats[i];
      var hw = player.w / 2;
      if (!(player.x + hw > p.x && player.x - hw < p.x + p.w)) continue;
      if (player.vy >= 0 && prevY <= p.y + 1 && player.y >= p.y) {
        if (!landedPlat || p.y < landedPlat.y) { landedPlat = p; landedIdx = i; }
      }
    }
    if (landedPlat) {
      var bouncyNow = (worldKey === 'pong' && pongSys && pongSys.isBouncy());
      if (bouncyNow && player.vy > 120) {
        var impact = player.vy;
        player.y = landedPlat.y;
        player.vy = pongSys.bounce(landedIdx, impact);
        player.onGround = false; player.coyote = 0;
        player.vx += (Math.random() - 0.5) * ((level.bounce && level.bounce.drift) || 80) * 2;
        if (window.Effects) window.Effects.burst(player.x, player.y, '#a4ff4d', 6);
      } else {
        player.y = landedPlat.y; player.vy = 0; player.onGround = true; player.coyote = 0.1;
      }
    }
    for (var j = 0; j < plats.length; j++) {
      var q = plats[j];
      if (player.y - 6 > q.y && player.y - player.h < q.y + q.h) {
        if (player.x + player.w / 2 > q.x && player.x - player.w / 2 < q.x + 8 && player.vx > 0 && Math.abs(player.y - q.y) > 12) player.x = q.x - player.w / 2;
        if (player.x - player.w / 2 < q.x + q.w && player.x + player.w / 2 > q.x + q.w - 8 && player.vx < 0 && Math.abs(player.y - q.y) > 12) player.x = q.x + q.w + player.w / 2;
      }
    }
  }

  var last = 0;
  function frame(ts) {
    requestAnimationFrame(frame);
    if (!last) last = ts;
    var dt = Math.min(0.033, (ts - last) / 1000); last = ts;
    tGlobal += dt;
    if (state !== 'play') {
      ctx.save();
      window.World.drawBackground(ctx, W, H, tGlobal * 40, tGlobal);
      window.World.drawEye(ctx, W, 0, tGlobal, W / 2);
      ctx.restore();
      return;
    }
    if (!won) player.update(dt, input, phys);
    else { winT += dt; if (winT > 2.2) nextLevel(); }
    collide(dt);
    if (window.Effects) window.Effects.update(dt);
    if (pingSys) pingSys.update(dt, player, plats);
    if (pongSys) { pongSys.update(dt, player); pongSys.checkHazards(player, plats); }
    if (snapSys) snapSys.update(dt, player, plats);
    if (!player.dead && player.y > 640) { player.kill(false); if (window.Effects) window.Effects.toast('FELL!', 800); }
    if (!player.dead && !won && player.x > level.endX - 60) {
      won = true; winT = 0;
      if (window.GameAudio) window.GameAudio.win();
      var more = (levelIdx + 1 < levelCount(worldKey)) ? ' · press N / auto-advance to ' + worldKey.toUpperCase() + ' ' + (levelIdx + 2) : ' · world clear!';
      if (window.Effects) window.Effects.toast('✔ ' + level.name + ' CLEARED!<br><span style="font-size:14px">deaths: ' + deaths + more + '</span>', 2000);
      try {
        localStorage.setItem('pps_win_' + worldKey + '_' + levelIdx, '1');
        localStorage.setItem('pps_win_' + worldKey, String((parseInt(localStorage.getItem('pps_win_' + worldKey) || '0', 10) || 0) + 1));
      } catch (e) {}
    }
    if (player.dead && !deathCounted) {
      deathCounted = true; deaths++; hudDeaths.textContent = 'Rebirths: ' + deaths;
      jumpscare(player.snapDeath); // jumpscare on EVERY death, worse for head-snaps
    }
    if (player.dead && player.deadT > (player.snapDeath ? 2.2 : 1.4) && !won) rebirth(false);
    var target = Math.max(-80, Math.min(level.endX - 700, player.x - 320));
    camX += (target - camX) * Math.min(1, dt * 6);

    ctx.save();
    ctx.clearRect(0, 0, W, H);
    window.World.drawBackground(ctx, W, H, camX, tGlobal);
    window.Effects.applyShake(ctx);
    window.World.drawEye(ctx, W, camX, tGlobal, player.x);
    var bouncy = (worldKey === 'pong' && pongSys && pongSys.isBouncy());
    for (var i = 0; i < level.plats.length; i++) {
      var p = level.plats[i];
      var sq = (worldKey === 'pong' && pongSys) ? pongSys.squashAt(i) : 0;
      window.World.drawPlatform(ctx, p.x - camX, p.y, p.w, p.h, tGlobal, !!bouncy, sq);
    }
    if (worldKey === 'pong' && pongSys) pongSys.drawStatic(ctx, camX, plats, tGlobal);
    if (worldKey === 'ping' && pingSys) pingSys.draw(ctx, camX);
    if (worldKey === 'snap' && snapSys) snapSys.draw(ctx, camX, tGlobal);
    window.World.drawGoal(ctx, level.endX - 80 - camX, 440, tGlobal);
    window.Effects.draw(ctx, camX);
    player.draw(ctx, camX, tGlobal);
    // dramatic death flash: red vignette right after the kill
    if (player.dead) {
      var fa = player.snapDeath ? Math.max(0, 0.55 - player.deadT * 0.3) : Math.max(0, 0.35 - player.deadT * 0.3);
      if (fa > 0) { ctx.fillStyle = 'rgba(255,10,10,' + fa.toFixed(3) + ')'; ctx.fillRect(-20, -20, W + 40, H + 40); }
    }
    // banners
    ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'left';
    var tag = worldKey === 'ping' ? 'PING ' + (levelIdx + 1) + '/5 — trust nothing'
      : worldKey === 'pong' ? 'PONG ' + (levelIdx + 1) + '/5 — ' + (bouncy ? '⚠ BOUNCY FLOOR ⚠' : 'floor stable… for now')
      : 'SNAP ' + (levelIdx + 1) + '/5 — normal floor. steps crack. head may snap · cause hidden';
    ctx.fillText(tag, 12, H - 12);
    if (bouncy) {
      ctx.fillStyle = 'rgba(255,40,40,' + (0.6 + 0.4 * Math.sin(tGlobal * 10)) + ')';
      ctx.font = 'bold 26px monospace'; ctx.textAlign = 'center';
      ctx.fillText('⚠ BOUNCY ⚠', W / 2, 60);
    }
    ctx.restore();
  }
  refreshMenuProgress();
  requestAnimationFrame(frame);
})();
