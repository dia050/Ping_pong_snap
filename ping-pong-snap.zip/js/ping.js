/* PING world: pop-up spikes with zero warning + ping sound. Global: PingSys */
(function () {
  function PingSys(level) {
    this.cfg = level.pop;
    this.pops = [];
    this.timer = 1.2;
  }
  PingSys.prototype.reset = function () { this.pops = []; this.timer = 1.0; };
  function groundAt(plats, x) {
    for (var i = 0; i < plats.length; i++) {
      var p = plats[i];
      if (x >= p.x && x <= p.x + p.w) return p.y;
    }
    return null;
  }
  PingSys.prototype.update = function (dt, player, plats) {
    this.timer -= dt;
    if (this.timer <= 0 && !player.dead) {
      var n = this.cfg.multi || 1;
      for (var k = 0; k < n; k++) {
        var ahead = (Math.random() < 0.65 ? 1 : -1) * (60 + Math.random() * 200);
        var sx = player.x + ahead + (k * 70);
        var gy = groundAt(plats, sx);
        if (gy !== null) {
          this.pops.push({ x: sx - this.cfg.w / 2, y: gy, w: this.cfg.w, h: 0, maxH: this.cfg.h, state: 'arise', t: 0 });
        }
      }
      if (window.GameAudio) window.GameAudio.ping();
      var c = this.cfg;
      this.timer = c.minInterval + Math.random() * (c.maxInterval - c.minInterval);
    }
    for (var i = this.pops.length - 1; i >= 0; i--) {
      var p = this.pops[i]; p.t += dt;
      if (p.state === 'arise') { p.h = p.maxH * (p.t / this.cfg.ariseTime); if (p.t >= this.cfg.ariseTime) { p.h = p.maxH; p.state = 'lethal'; p.t = 0; } }
      else if (p.state === 'lethal') {
        // kill on overlap with player body
        if (!player.dead &&
          player.x + 11 > p.x && player.x - 11 < p.x + p.w &&
          player.y > p.y - p.h - 6 && player.y - player.h < p.y) {
          player.kill(false);
          if (window.Effects) window.Effects.toast('PINGED!', 900);
        }
        if (p.t >= this.cfg.lethalTime) { p.state = 'retract'; p.t = 0; }
      }
      else { p.h = p.maxH * (1 - p.t / this.cfg.retractTime); if (p.t >= this.cfg.retractTime) this.pops.splice(i, 1); }
    }
  };
  PingSys.prototype.draw = function (ctx, camX) {
    for (var i = 0; i < this.pops.length; i++) {
      var p = this.pops[i];
      if (p.h > 2) window.World.drawSpike(ctx, p.x - camX, p.y, p.w, p.h, '#e8ecf1');
    }
  };
  window.PingSys = PingSys;
})();
