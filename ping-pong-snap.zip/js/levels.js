/* Ping-Pong-Snap: full 15 levels (5 per world). */
(function () {
  var GROUND_Y = 440;

  function straightRoad(n, gapEvery, gapW, startX, segW) {
    var plats = [], x = startX || 0;
    for (var i = 0; i < n; i++) {
      plats.push({ x: x, y: GROUND_Y, w: segW || 300, h: 100 });
      x += (segW || 300);
      if (gapEvery && (i % gapEvery === gapEvery - 1)) x += (gapW || 70);
    }
    return { plats: plats, endX: x };
  }
  // spread N spike/ceiling spots safely inside platforms (avoid edges + start + goal)
  function spreadSpots(plats, count, inset) {
    var spots = [], m = inset || 90;
    for (var i = 0; i < count; i++) {
      var pi = Math.floor((i + 0.5) * plats.length / count);
      pi = Math.max(1, Math.min(plats.length - 2, pi)); // keep off spawn + goal plats
      var p = plats[pi];
      var dx = p.x + m + ((i * 137) % Math.max(40, p.w - m * 2));
      spots.push({ dx: Math.round(dx), plat: pi });
    }
    return spots;
  }

  // ---------- PING 1-5: pop-up spikes, faster + longer ----------
  var pingCfg = [
    { segs: 10, gap: 70,  minI: 1.10, maxI: 2.00, arise: 0.090, lethal: 0.45, multi: 1 },
    { segs: 11, gap: 75,  minI: 0.90, maxI: 1.60, arise: 0.070, lethal: 0.48, multi: 1 },
    { segs: 12, gap: 80,  minI: 0.70, maxI: 1.30, arise: 0.060, lethal: 0.50, multi: 2 },
    { segs: 13, gap: 85,  minI: 0.50, maxI: 1.00, arise: 0.050, lethal: 0.52, multi: 2 },
    { segs: 14, gap: 92,  minI: 0.35, maxI: 0.80, arise: 0.040, lethal: 0.55, multi: 3 }
  ];
  var pingLevels = pingCfg.map(function (c, li) {
    var r = straightRoad(c.segs, 3, c.gap, -100, 300);
    return {
      name: 'PING ' + (li + 1), world: 'ping', plats: r.plats, endX: r.endX,
      start: { x: 60, y: 300 },
      hint: 'PING ' + (li + 1) + ': no-warning pop spikes' + (c.multi > 1 ? ' x' + c.multi + ' at once' : '') + '. Keep moving!',
      pop: { minInterval: c.minI, maxInterval: c.maxI, ariseTime: c.arise, lethalTime: c.lethal, retractTime: 0.25, w: 46, h: 64, multi: c.multi }
    };
  });

  // ---------- PONG 1-5: normal road + obstacles, RANDOM bouncy curse + squish ceilings ----------
  // L1 gentle intro -> L5 brutal. Ceilings get lower, bouncy more often + stronger.
  var pongCfg = [
    { segs: 10, gap: 80,  spikes: 3, bars: 1, ceils: 2, ceilBottom: 312, pMin: 7,  pMax: 11, dur: 2.2, mult: 1.50, drift: 60 },
    { segs: 11, gap: 85,  spikes: 4, bars: 2, ceils: 3, ceilBottom: 302, pMin: 6,  pMax: 9,  dur: 2.6, mult: 1.65, drift: 85 },
    { segs: 12, gap: 90,  spikes: 5, bars: 2, ceils: 4, ceilBottom: 292, pMin: 5,  pMax: 8,  dur: 3.0, mult: 1.80, drift: 105 },
    { segs: 13, gap: 95,  spikes: 6, bars: 3, ceils: 5, ceilBottom: 282, pMin: 4,  pMax: 7,  dur: 3.4, mult: 1.95, drift: 125 },
    { segs: 14, gap: 100, spikes: 7, bars: 3, ceils: 6, ceilBottom: 272, pMin: 3,  pMax: 6,  dur: 3.8, mult: 2.10, drift: 150 }
  ];
  var pongLevels = pongCfg.map(function (c, li) {
    var r = straightRoad(c.segs, 3, c.gap, -100, 300);
    var sp = spreadSpots(r.plats, c.spikes, 90).map(function (s, i) { return { dx: s.dx, w: 55 + ((i * 53) % 40) }; });
    var bars = spreadSpots(r.plats, c.bars, 110).map(function (s) { return { dx: s.dx - 60, w: 220, h: 80 }; });
    var ceils = spreadSpots(r.plats, c.ceils, 70).map(function (s, i) {
      var w = 240 + ((i * 97) % 120);
      return { x: s.dx - 40, w: w, top: c.ceilBottom - 26, bottom: c.ceilBottom, spiked: li >= 3 && (i % 2 === 0) };
    });
    return {
      name: 'PONG ' + (li + 1), world: 'pong', plats: r.plats, endX: r.endX,
      start: { x: 60, y: 200 },
      staticSpikes: sp, lowBars: bars, ceilings: ceils,
      hint: 'PONG ' + (li + 1) + ': obstacles ahead — floor randomly turns BOUNCY, you launch into the ceiling. Watch the glow!',
      bounce: { mult: c.mult, drift: c.drift },
      curse: { periodMin: c.pMin, periodMax: c.pMax, duration: c.dur }
    };
  });

  // ---------- SNAP 1-5: branch-carpet floor (constant snap) + hidden multi-rules ----------
  var snapCfg = [
    { segs: 10, spikes: 2, rules: 1, step: 75 },
    { segs: 11, spikes: 3, rules: 1, step: 70 },
    { segs: 12, spikes: 4, rules: 2, step: 65 },
    { segs: 13, spikes: 5, rules: 2, step: 60 },
    { segs: 14, spikes: 6, rules: 3, step: 55 }
  ];
  var snapLevels = snapCfg.map(function (c, li) {
    var r = straightRoad(c.segs, 4, 70 + li * 5, -100, 300);
    var ez = spreadSpots(r.plats, c.spikes, 100).map(function (s) { return { dx: s.dx, w: 44 }; });
    // dense branch carpet across the whole run (every ~step px where ground exists)
    var joints = [];
    for (var x = 250; x < r.endX - 250; x += c.step) {
      var onGround = false;
      for (var i = 0; i < r.plats.length; i++) { var p = r.plats[i]; if (x >= p.x + 10 && x <= p.x + p.w - 10) { onGround = true; break; } }
      if (onGround) joints.push(Math.round(x + ((joints.length * 31) % 17) - 8));
    }
    var up = [
      { x: 900, y: 320, w: 420, h: 60 },
      { x: 1500 + li * 60, y: 320, w: 360, h: 60 },
      { x: 2100 + li * 80, y: 310, w: li >= 2 ? 340 : 0, h: 60 }
    ].filter(function (b) { return b.w > 0; });
    return {
      name: 'SNAP ' + (li + 1), world: 'snap', plats: r.plats, endX: r.endX,
      start: { x: 60, y: 300 },
      upperBranch: up, joints: joints, easySpikes: ez,
      hint: 'SNAP ' + (li + 1) + ': floor looks normal but steps go SNAP (decoy). ' + c.rules + ' hidden curse' + (c.rules > 1 ? 's' : '') + ', reshuffled every rebirth.',
      curseCount: c.rules, tight: li // 0..4 -> tighter hidden limits
    };
  });

  window.PPS_LEVELS = { groundY: GROUND_Y, ping: pingLevels, pong: pongLevels, snap: snapLevels };

  window.PPS_DIFFICULTY = {
    ping: pingCfg, pong: pongCfg, snap: snapCfg
  };
})();
