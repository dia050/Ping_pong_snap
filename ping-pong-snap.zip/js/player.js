/* Player: full-control stickman "You". Global: Player */
(function () {
  function Player(x, y) { this.reset(x, y); }
  Player.prototype.reset = function (x, y) {
    this.x = x; this.y = y; this.vx = 0; this.vy = 0;
    this.w = 22; this.h = 52;
    this.onGround = false; this.face = 1; this.runPhase = 0;
    this.coyote = 0; this.jumpBuf = 0;
    this.jumps = 0; this.dist = 0; this.alive = 0; this.still = 0; this.leftPresses = 0;
    this.dead = false; this.deadT = 0; this.snapDeath = false;
    this.headX = 0; this.headY = 0; this.headVX = 0; this.headVY = 0; this.headRot = 0;
  };
  Player.prototype.update = function (dt, input, phys) {
    if (this.dead) { this.deadT += dt; if (this.snapDeath) { this.headVY += 2400 * dt; this.headX += this.headVX * dt; this.headY += this.headVY * dt; this.headRot += 14 * dt; } return; }
    this.alive += dt;
    var accel = this.onGround ? 2600 : 1700;
    var max = phys.moveSpeed || 270;
    if (input.left) { this.vx -= accel * dt; this.face = -1; }
    if (input.right) { this.vx += accel * dt; this.face = 1; }
    if (!input.left && !input.right) {
      var f = this.onGround ? 2200 * dt : 300 * dt;
      if (Math.abs(this.vx) <= f) this.vx = 0; else this.vx -= Math.sign(this.vx) * f;
    }
    this.vx = Math.max(-max - 120, Math.min(max + 120, this.vx));
    this.vy += (phys.gravity || 2100) * dt;
    if (this.vy > 1400) this.vy = 1400;
    this.coyote -= dt; this.jumpBuf -= dt;
    if (this.jumpBuf > 0 && (this.onGround || this.coyote > 0)) {
      this.vy = -(phys.jumpForce || 740); this.onGround = false; this.coyote = 0; this.jumpBuf = 0;
      this.jumps++;
      if (window.GameAudio) window.GameAudio.jump();
      if (window.Effects) window.Effects.jumpPuff(this.x, this.y + this.h);
    }
    var prevX = this.x;
    this.x += this.vx * dt; this.y += this.vy * dt;
    this.dist += Math.abs(this.x - prevX);
    if (Math.abs(this.vx) > 20) { this.runPhase += dt * (6 + Math.abs(this.vx) * 0.03); this.still = 0; }
    else if (this.onGround) { this.still += dt; }
  };
  Player.prototype.kill = function (snap) {
    if (this.dead) return;
    this.dead = true; this.deadT = 0; this.snapDeath = !!snap;
    if (snap) {
      this.headX = this.x; this.headY = this.y - 34;
      this.headVX = this.face * (320 + Math.random() * 220); this.headVY = -820; this.headRot = 0;
    }
    if (window.GameAudio) { if (snap) window.GameAudio.headSnap(); else window.GameAudio.die(); }
    if (window.Effects) {
      if (snap) {
        window.Effects.burst(this.x, this.y - 20, '#ff5d5d', 30);
        window.Effects.burst(this.x, this.y - 30, '#ffffff', 14);
        window.Effects.burst(this.x, this.y - 10, '#7a0000', 16);
        window.Effects.trauma(24);
      } else {
        window.Effects.burst(this.x, this.y, '#37e6ff', 14);
        window.Effects.trauma(12);
      }
    }
  };
  Player.prototype.draw = function (ctx, camX, t) {
    var sx = Math.round(this.x - camX), sy = Math.round(this.y);
    ctx.save(); ctx.translate(sx, sy);
    ctx.shadowColor = '#00e5ff'; ctx.shadowBlur = 14;
    ctx.lineCap = 'round';
    var run = Math.abs(this.vx) > 30 && this.onGround;
    var sw = run ? Math.sin(this.runPhase * 6) * 10 : 0;
    var airK = !this.onGround ? 1 : 0;
    function limb(x1, y1, x2, y2) {
      ctx.strokeStyle = '#001318'; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.strokeStyle = '#00e5ff'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    }
    if (this.snapDeath && this.dead) {
      // headless body + flying head
      limb(0, -6, -6 + sw * 0.4, 22); limb(0, -6, 6 - sw * 0.4, 22);
      limb(0, -22, -10 * this.face, -4); limb(0, -22, 10 * this.face, -8 - airK * 4);
      ctx.strokeStyle = '#001318'; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(0, -6); ctx.stroke();
      ctx.strokeStyle = '#00e5ff'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(0, -6); ctx.stroke();
      // neck stub
      ctx.fillStyle = '#ff5d5d'; ctx.fillRect(-4, -26, 8, 5);
      // flying head
      ctx.save(); ctx.translate(this.headX - this.x, this.headY - this.y); ctx.rotate(this.headRot);
      ctx.strokeStyle = '#001318'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.arc(0, 0, 10, 0, 7); ctx.stroke();
      ctx.fillStyle = '#00e5ff'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, 7); ctx.fill();
      // crack
      ctx.strokeStyle = '#ff2222'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-8, -4); ctx.lineTo(0, 0); ctx.lineTo(-4, 8); ctx.stroke();
      ctx.restore();
    } else {
      var bob = run ? Math.abs(Math.sin(this.runPhase * 6)) * -2 : Math.sin(t * 2) * 1;
      var hy = -38 + bob - airK * 3;
      limb(0, -16, -7 + sw * 0.5, 0); limb(0, -16, 7 - sw * 0.5, 0);
      limb(0, -30, -11 * this.face, -12 + sw * 0.3); limb(0, -30, 11 * this.face, -16 - sw * 0.3 - airK * 5);
      ctx.strokeStyle = '#001318'; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(0, -30); ctx.lineTo(0, -14); ctx.stroke();
      ctx.strokeStyle = '#00e5ff'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(0, -30); ctx.lineTo(0, -14); ctx.stroke();
      // head
      ctx.strokeStyle = '#001318'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.arc(0, hy, 11, 0, 7); ctx.stroke();
      ctx.fillStyle = '#00e5ff'; ctx.beginPath(); ctx.arc(0, hy, 11, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(-3, hy - 3, 3, 0, 7); ctx.fill();
      // dash swirl when fast
      if (Math.abs(this.vx) > 180) {
        ctx.globalAlpha = 0.5; ctx.strokeStyle = '#bff6ff'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(-this.face * 12, -18, 10 + Math.sin(t * 20) * 2, 0, 5); ctx.stroke();
        ctx.globalAlpha = 1;
      }
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#fff'; ctx.font = 'bold 15px Consolas,monospace'; ctx.textAlign = 'center';
      ctx.fillText('You', 0, hy - 20);
    }
    ctx.restore();
  };
  window.Player = Player;
})();
