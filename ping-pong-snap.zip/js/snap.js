/* SNAP: branch-carpet floor (constant snap-snap decoy) + 1-3 hidden death curses reshuffled every rebirth. */
(function () {
  var RULES = ['steps', 'jumps', 'alive', 'still', 'zone', 'upper', 'left'];
  function SnapSys(level) { this.level = level; this.roll(); this.stepAcc = 0; this.snapAlt = false; this.wasAir = false; }
  function pickN(arr, n) {
    var a = arr.slice(), out = [];
    while (out.length < n && a.length) out.push(a.splice(Math.floor(Math.random() * a.length), 1)[0]);
    return out;
  }
  SnapSys.prototype.roll = function () {
    var lvl = this.level;
    var n = Math.max(1, Math.min(3, lvl.curseCount || 1));
    var tight = lvl.tight || 0;
    var par = (lvl.endX || 3000) / 240; // ~par seconds for a decent run
    var rules = pickN(RULES, n);
    this.curses = rules.map(function (r) {
      var c = { rule: r };
      if (r === 'steps') c.limit = lvl.endX * (0.85 + Math.random() * 0.5) - tight * 120;
      else if (r === 'jumps') c.limit = Math.max(4, 7 + Math.floor(Math.random() * 6) - tight);
      else if (r === 'alive') c.limit = Math.max(par + 3, par + 7 + Math.random() * 10 - tight * 1.6);
      else if (r === 'still') c.limit = Math.max(1.3, 2.4 + Math.random() * 2.2 - tight * 0.28);
      else if (r === 'zone') { c.zoneX = 600 + Math.random() * Math.max(500, (lvl.endX || 3000) - 1200); c.zoneW = 120 + tight * 18 + Math.random() * 40; }
      else if (r === 'left') c.limit = Math.max(2, 4 + Math.floor(Math.random() * 4) - (tight >= 3 ? 1 : 0));
      return c;
    });
    this.jointFired = {};
  };
  SnapSys.prototype.reset = function () { this.roll(); this.stepAcc = 0; };
  SnapSys.prototype.update = function (dt, player, plats) {
    var lvl = this.level;
    // Floor looks NORMAL — but walking/landing cracks with snap sounds (invisible branches, pure decoy).
    if (!player.dead && player.onGround && Math.abs(player.vx) > 40) {
      this.stepAcc += Math.abs(player.vx) * dt;
      var every = 52 + ((lvl.tight || 0) * 2);
      if (this.stepAcc > every) {
        this.stepAcc = 0; this.snapAlt = !this.snapAlt;
        if (window.GameAudio) { if (this.snapAlt) window.GameAudio.twigSnap(); else window.GameAudio.snapStep(); }
        if (window.Effects && Math.random() < 0.35) window.Effects.burst(player.x, player.y - 4, '#c9a06a', 2);
      }
    }
    if (!player.dead && this.wasAir && player.onGround) {
      if (window.GameAudio) window.GameAudio.twigSnap(); // landing crack
    }
    this.wasAir = !player.dead && !player.onGround;
    if (player.dead) return null;
    // hidden curses — ANY one kills, cause never shown
    for (var k = 0; k < this.curses.length; k++) {
      var c = this.curses[k], kill = false;
      if (c.rule === 'steps' && player.dist > c.limit) kill = true;
      else if (c.rule === 'jumps' && player.jumps >= c.limit) kill = true;
      else if (c.rule === 'alive' && player.alive > c.limit) kill = true;
      else if (c.rule === 'still' && player.still > c.limit) kill = true;
      else if (c.rule === 'zone' && player.onGround && player.x > c.zoneX && player.x < c.zoneX + c.zoneW) kill = true;
      else if (c.rule === 'upper' && this.touchedUpper(player)) kill = true;
      else if (c.rule === 'left' && player.leftPresses >= c.limit) kill = true;
      if (kill) {
        player.kill(true);
        if (window.Effects) window.Effects.toast('HEAD SNAP!<br><span style="font-size:14px">' + this.curses.length + ' hidden curse' + (this.curses.length > 1 ? 's' : '') + ' · reshuffled · cause hidden</span>', 1700);
        return 'snap';
      }
    }
    // easy visible spikes (fair, jumpable)
    var ez = lvl.easySpikes || [];
    for (var s = 0; s < ez.length; s++) {
      var sx = ez[s].dx, sw = ez[s].w, gy = null;
      for (var p = 0; p < plats.length; p++) { var pl = plats[p]; if (sx >= pl.x && sx <= pl.x + pl.w) { gy = pl.y; break; } }
      if (gy !== null && player.x + 10 > sx && player.x - 10 < sx + sw && player.y > gy - 32 && player.y - player.h < gy) {
        player.kill(false);
        if (window.Effects) window.Effects.toast('SNAP SPIKE!', 800);
        return 'spike';
      }
    }
    return null;
  };
  SnapSys.prototype.touchedUpper = function (player) {
    var up = this.level.upperBranch || [];
    for (var i = 0; i < up.length; i++) {
      var b = up[i];
      if (player.x > b.x && player.x < b.x + b.w && Math.abs(player.y - b.y) < 40 && player.onGround) return true;
    }
    return false;
  };
  SnapSys.prototype.draw = function (ctx, camX, t) {
    var lvl = this.level;
    // Fork paths look like normal platforms — no twig visuals on the floor anymore.
    var up = lvl.upperBranch || [];
    for (var i = 0; i < up.length; i++) window.World.drawPlatform(ctx, up[i].x - camX, up[i].y, up[i].w, up[i].h, t, false, 0);
    var ez = lvl.easySpikes || [];
    for (var s = 0; s < ez.length; s++) {
      var sx = ez[s].dx, gy = null, plats = lvl.plats;
      for (var p = 0; p < plats.length; p++) { var pl = plats[p]; if (sx >= pl.x && sx <= pl.x + pl.w) { gy = pl.y; break; } }
      if (gy !== null) window.World.drawSpike(ctx, sx - camX, gy, ez[s].w, 30, '#e8ecf1');
    }
  };
  window.SnapSys = SnapSys;
})();
