/* World rendering: industrial green background + sci-fi platforms + stalker eye. Global: World */
(function () {
  function rnd(seed) { var x = Math.sin(seed * 127.1) * 43758.5453; return x - Math.floor(x); }

  function drawBackground(ctx, W, H, camX, t) {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#1d3a24'); g.addColorStop(0.6, '#16291c'); g.addColorStop(1, '#0d1a10');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // wall panels
    ctx.save(); ctx.globalAlpha = 0.5;
    var off = -(camX * 0.3 % 220);
    for (var x = off - 220; x < W + 220; x += 220) {
      ctx.fillStyle = '#1b3320'; ctx.fillRect(x + 10, 20, 200, H - 40);
      ctx.strokeStyle = '#0a140c'; ctx.lineWidth = 3; ctx.strokeRect(x + 10, 20, 200, H - 40);
      ctx.fillStyle = '#24402a';
      for (var b = 0; b < 4; b++) { ctx.beginPath(); ctx.arc(x + 40 + b * 45, 55, 9, 0, 7); ctx.fill(); }
      ctx.fillStyle = '#0f2013';
      ctx.fillRect(x + 30, 90, 160, 200);
      ctx.fillStyle = '#1e3a25';
      for (var r = 0; r < 5; r++) ctx.fillRect(x + 40, 100 + r * 38, 140, 22);
    }
    ctx.restore();
    // pipes
    ctx.save(); ctx.globalAlpha = 0.9;
    var poff = -(camX * 0.5 % 420);
    for (var p = poff - 420; p < W + 420; p += 420) {
      ctx.fillStyle = '#243d28'; ctx.fillRect(p, 0, 46, H);
      ctx.fillStyle = '#314f36'; ctx.fillRect(p + 8, 0, 10, H);
      ctx.fillStyle = '#101c12'; ctx.fillRect(p + 34, 0, 6, H);
      ctx.fillStyle = '#3a5a40'; ctx.fillRect(p - 6, 60, 58, 14); ctx.fillRect(p - 6, H - 160, 58, 14);
    }
    ctx.restore();
    // drifting glow dots
    ctx.save(); ctx.globalAlpha = 0.25;
    for (var i = 0; i < 24; i++) {
      var dx = ((i * 173 - camX * 0.2) % (W + 100) + W + 100) % (W + 100) - 50;
      var dy = 40 + rnd(i) * (H - 120) + Math.sin(t * 0.7 + i) * 6;
      ctx.fillStyle = i % 3 ? '#7dff9a' : '#ffe27d';
      ctx.beginPath(); ctx.arc(dx, dy, 3 + rnd(i * 7) * 5, 0, 7); ctx.fill();
    }
    ctx.restore();
  }

  function drawEye(ctx, W, camX, t, px) {
    var ex = W * 0.62, ey = 118 + Math.sin(t * 1.2) * 8;
    ctx.save();
    ctx.globalAlpha = 0.95;
    // glow
    var gl = ctx.createRadialGradient(ex, ey, 10, ex, ey, 150);
    gl.addColorStop(0, 'rgba(120,255,170,0.25)'); gl.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(ex, ey, 150, 0, 7); ctx.fill();
    // dome
    ctx.fillStyle = '#0c1710'; ctx.beginPath(); ctx.ellipse(ex, ey, 120, 92, 0, 0, 7); ctx.fill();
    var body = ctx.createLinearGradient(ex - 120, ey - 90, ex + 120, ey + 90);
    body.addColorStop(0, '#e8f4ec'); body.addColorStop(0.35, '#9fb3a6'); body.addColorStop(0.55, '#5c6f63'); body.addColorStop(1, '#2c3830');
    ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(ex, ey, 112, 84, 0, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(180,255,220,0.35)'; ctx.beginPath(); ctx.ellipse(ex - 20, ey - 42, 70, 30, -0.3, 0, 7); ctx.fill();
    // orange vents
    ctx.fillStyle = '#c97a1e';
    for (var s = -1; s <= 1; s += 2) for (var i = 0; i < 3; i++) {
      ctx.fillRect(ex + s * 78, ey - 34 + i * 26, 22, 16);
    }
    ctx.fillStyle = '#5a3000';
    for (var s2 = -1; s2 <= 1; s2 += 2) for (var j = 0; j < 3; j++) ctx.fillRect(ex + s2 * 78, ey - 34 + j * 26, 22, 3);
    // green gem (tracks player slightly)
    var look = Math.max(-10, Math.min(10, (px - camX - ex) * 0.02));
    ctx.fillStyle = '#0a2a12'; ctx.beginPath();
    ctx.moveTo(ex - 34 + look, ey - 26); ctx.lineTo(ex + 34 + look, ey - 26);
    ctx.lineTo(ex + 26 + look, ey + 34); ctx.lineTo(ex, ey + 52); ctx.lineTo(ex - 26 + look, ey + 34);
    ctx.closePath(); ctx.fill();
    var gem = ctx.createLinearGradient(ex, ey - 26, ex, ey + 52);
    gem.addColorStop(0, '#8dff9e'); gem.addColorStop(0.5, '#22d34d'); gem.addColorStop(1, '#0a6b24');
    ctx.fillStyle = gem; ctx.beginPath();
    ctx.moveTo(ex - 26 + look, ey - 20); ctx.lineTo(ex + 26 + look, ey - 20);
    ctx.lineTo(ex + 19 + look, ey + 30); ctx.lineTo(ex, ey + 44); ctx.lineTo(ex - 19 + look, ey + 30);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(ex - 12 + look, ey - 12, 8, 22);
    ctx.restore();
  }

  // Chunky platform exactly like screenshot: orange top, green capsule, pistons, hazard base
  function drawPlatform(ctx, sx, y, w, h, t, tramp, squash) {
    if (sx + w < -50 || sx > 2000) return;
    ctx.save(); ctx.translate(sx, y);
    if (squash) { ctx.translate(w / 2, 0); ctx.scale(1 + squash * 0.12, 1 - squash * 0.25); ctx.translate(-w / 2, 0); }
    // shadow / body
    ctx.fillStyle = '#0a140c'; ctx.fillRect(-4, -4, w + 8, h + 8);
    ctx.fillStyle = '#2b3f31'; ctx.fillRect(0, 0, w, h);
    // orange top strip with zigzag
    var topH = 22;
    var tg = ctx.createLinearGradient(0, 0, 0, topH);
    tg.addColorStop(0, tramp ? '#ffe27d' : '#ffb13d'); tg.addColorStop(1, tramp ? '#ffb13d' : '#e07f16');
    ctx.fillStyle = tg; ctx.fillRect(0, 0, w, topH);
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    for (var x = 0; x < w; x += 24) { ctx.moveTo(x, topH); ctx.lineTo(x + 12, 4); ctx.lineTo(x + 24, topH); }
    ctx.fill();
    ctx.fillStyle = '#12341a'; ctx.fillRect(0, topH - 3, w, 3);
    // side pistons
    ctx.fillStyle = '#c9d4cc'; ctx.fillRect(-10, topH + 4, 10, h - topH - 8); ctx.fillRect(w, topH + 4, 10, h - topH - 8);
    ctx.fillStyle = '#ff9a2a'; ctx.fillRect(-10, topH + 14, 10, h - topH - 28); ctx.fillRect(w, topH + 14, 10, h - topH - 28);
    ctx.fillStyle = '#5a3000'; ctx.fillRect(-10, topH + 14, 10, 4); ctx.fillRect(w, topH + 14, 10, 4);
    // green capsule center
    var capY = topH + 12, capH = 44;
    ctx.fillStyle = '#0e2a14'; ctx.fillRect(8, capY - 4, w - 16, capH + 8);
    var cg = ctx.createLinearGradient(0, capY, 0, capY + capH);
    if (tramp) { cg.addColorStop(0, '#d8ff9e'); cg.addColorStop(0.5, '#5dff4d'); cg.addColorStop(1, '#1a9e2a'); }
    else { cg.addColorStop(0, '#b9f5c4'); cg.addColorStop(0.25, '#4ade80'); cg.addColorStop(1, '#166534'); }
    ctx.fillStyle = cg;
    ctx.beginPath();
    var r = 12;
    ctx.moveTo(14, capY);
    ctx.lineTo(w - 14, capY); ctx.quadraticCurveTo(w - 8, capY, w - 8, capY + r);
    ctx.lineTo(w - 8, capY + capH - r); ctx.quadraticCurveTo(w - 8, capY + capH, w - 14, capY + capH);
    ctx.lineTo(14, capY + capH); ctx.quadraticCurveTo(8, capY + capH, 8, capY + capH - r);
    ctx.lineTo(8, capY + r); ctx.quadraticCurveTo(8, capY, 14, capY); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(16, capY + 6, w - 32, 8);
    if (tramp) {
      ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'center';
      ctx.fillText('◠ TRAMPOLINE ◠', w / 2, capY + capH / 2 + 5);
    }
    // hazard chevrons bottom
    var hzY = h - 30;
    ctx.fillStyle = '#ff9a2a'; ctx.fillRect(8, hzY, w - 16, 22);
    ctx.fillStyle = '#1a2b1d';
    for (var hx = 8; hx < w - 16; hx += 36) {
      ctx.beginPath(); ctx.moveTo(hx, hzY + 22); ctx.lineTo(hx + 18, hzY); ctx.lineTo(hx + 30, hzY); ctx.lineTo(hx + 12, hzY + 22); ctx.fill();
    }
    ctx.strokeStyle = '#0a140c'; ctx.lineWidth = 3; ctx.strokeRect(0, 0, w, h);
    ctx.restore();
  }

  function drawSpike(ctx, sx, y, w, h, color) {
    ctx.save(); ctx.translate(sx, y);
    ctx.fillStyle = '#000'; ctx.fillRect(-2, -h - 2, w + 4, h + 4);
    ctx.fillStyle = color || '#c8ccd2';
    var teeth = Math.max(2, Math.round(w / 16));
    var tw = w / teeth;
    for (var i = 0; i < teeth; i++) {
      ctx.beginPath(); ctx.moveTo(i * tw, 0); ctx.lineTo(i * tw + tw / 2, -h); ctx.lineTo(i * tw + tw, 0); ctx.fill();
      ctx.fillStyle = 'rgba(255,80,80,0.85)'; ctx.fillRect(i * tw + tw / 2 - 2, -h, 4, 10);
      ctx.fillStyle = color || '#c8ccd2';
    }
    ctx.fillStyle = '#ff2a2a'; ctx.fillRect(0, -3, w, 3);
    ctx.restore();
  }

  function drawGoal(ctx, sx, y, t) {
    ctx.save(); ctx.translate(sx, y);
    var bob = Math.sin(t * 3) * 4;
    ctx.fillStyle = '#04120a'; ctx.fillRect(-8, -120 + bob, 72, 120);
    var g = ctx.createLinearGradient(0, -120, 0, 0);
    g.addColorStop(0, '#4ade80'); g.addColorStop(1, '#065f46');
    ctx.fillStyle = g; ctx.fillRect(0, -112 + bob, 56, 104);
    ctx.fillStyle = '#d1fae5'; ctx.fillRect(8, -100 + bob, 40, 10);
    ctx.fillStyle = '#fff'; ctx.font = 'bold 15px monospace'; ctx.textAlign = 'center';
    ctx.fillText('EXIT', 28, -60 + bob);
    ctx.strokeStyle = '#a7f3d0'; ctx.lineWidth = 3; ctx.strokeRect(0, -112 + bob, 56, 104);
    ctx.restore();
  }

  window.World = { drawBackground: drawBackground, drawEye: drawEye, drawPlatform: drawPlatform, drawSpike: drawSpike, drawGoal: drawGoal };
})();
